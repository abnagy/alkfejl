package hu.elte.transactiontracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionTrackerApplication.class, args);
	}
}
